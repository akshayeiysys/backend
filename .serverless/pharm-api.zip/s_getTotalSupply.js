
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pharmswap',
  applicationName: 'pharm-backend',
  appUid: 'xK6Pp3Dnc2fTtzRL9g',
  orgUid: '4805af2a-c936-4cd6-bf7c-bd3bc94731b7',
  deploymentUid: 'e167494f-c58b-4356-b14b-0a7af9384972',
  serviceName: 'pharm-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'pharm-api-dev-getTotalSupply', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getTotalSupply, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}